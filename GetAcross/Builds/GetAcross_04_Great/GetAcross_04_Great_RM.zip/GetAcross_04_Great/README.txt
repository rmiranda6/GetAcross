The recommended screen resolution is (1920 x 1080)

If you put it in anything higher or lower, 
you will get terrible results.